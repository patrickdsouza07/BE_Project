#Variables that contain the user credentials to access the twitter api.



ACCESS_TOKEN="708772345-1WIeBq7s1jIIq2rZkSwvNGgU0t3Tbv2rb1b2kFnD"
ACCESS_TOKEN_SECRET="RUCSyRwJQ46FlIelS3AcQvsma6UDo0JSgqG1QOYjQ1ZBL"
CONSUMER_KEY="KCFkyLOS6DgMZxEJkwvuzuVLw"
CONSUMER_SECRET="Aw3Tfd3zrmEq7JT2aoqyyWzkbH37E6tupY5DfD9EGTcJTqfahD"